##grunt-manifest
==============

This library is used to help generate manifest files and it is licensed under the MIT/X11 license.

Visit [here](https://github.com/gunta/grunt-manifest/blob/master/LICENSE-MIT) for a copy of the license. Or visit @guntas repo at: [https://github.com/gunta/grunt-manifest](https://github.com/gunta/grunt-manifest)


##zip.js
========

A library for zipping and unzipping files.

Visit [here](https://github.com/gildas-lormeau/zip.js) for BSD licensing information.

##DataStream.js
===============

A library for working with binary data. 

No license information provided on the associated github [repo](https://github.com/kig/DataStream.js).