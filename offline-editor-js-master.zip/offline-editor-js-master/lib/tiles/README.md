##FileSaver.js
==============

The awesome FileSaver.js library by Eli Grey is licensed under the MIT/X11 license.

Visit [here](https://raw.github.com/Esri/offline-editor-js/master/lib/tiles/LICENSE.md) for a copy of the license. Or visit Eli's repo at: [https://github.com/eligrey/FileSaver.js/](https://github.com/eligrey/FileSaver.js/)