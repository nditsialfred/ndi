3rd Party Library Licensing 
===========================


[xml2json](https://code.google.com/p/x2js/) A library for converting XML to JSON. Seems to handle complex XML is licensed under an Apache2 license.

[zip](http://gildas-lormeau.github.io/zip.js/) A lset of libraries for zipping and unzipping files is licensed as BSD [here](https://github.com/gildas-lormeau/zip.js).